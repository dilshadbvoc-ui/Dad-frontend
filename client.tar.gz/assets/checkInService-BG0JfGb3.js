import{r as e}from"./index-C5VOE2hL.js";const a=async s=>(await e.get("/checkins",{params:s})).data,c=async s=>(await e.post("/checkins",s)).data;export{c,a as g};
