import{r as s}from"./index-C5VOE2hL.js";const n=async()=>(await s.get("/call-settings")).data,r=async t=>(await s.put("/call-settings",t)).data;export{n as g,r as u};
