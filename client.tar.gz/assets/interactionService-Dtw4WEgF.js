import{r as s}from"./index-C5VOE2hL.js";const e=async t=>(await s.get("/interactions",{params:t})).data,r=async t=>(await s.post("/interactions",t)).data;export{r as c,e as g};
