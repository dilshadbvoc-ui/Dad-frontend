import{r as s}from"./index-C5VOE2hL.js";const n=async t=>(await s.get("/contacts",{params:t})).data,o=async t=>(await s.delete(`/contacts/${t}`)).data;export{o as d,n as g};
